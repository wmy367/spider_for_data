class DropCompanysSpiderdatesZhilianjobs < ActiveRecord::Migration

    def change
        drop_table :companys
        drop_table :spiderdates
        drop_table :zhilianjobs
    end
end
