class CreateSpiderDatesDropSpiderdates < ActiveRecord::Migration

    def change

        drop_table :spiderdates
        drop_table :companies_spiderdates

        create_table :spider_dates do |t|
            t.timestamps
            t.date :probe_time
        end

        create_table :companies_spider_dates, id: false do |t|
            t.belongs_to :companies
            t.belongs_to :spider_dates
        end

    end
end
