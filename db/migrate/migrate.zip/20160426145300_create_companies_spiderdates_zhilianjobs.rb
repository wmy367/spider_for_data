class CreateCompaniesSpiderdatesZhilianjobs < ActiveRecord::Migration

    def change
        create_table :companies do |t|
            t.string :company_name
            t.string :company_home_page
            t.string :zhilian_company_page_link
            t.string :jobs_link
            t.text :company_descript
            t.text :company_content
            t.timestamps
        end

        create_table :spiderdates do |t|
            t.timestamps
            t.date :probe_time
        end

        create_table :zhilianjobs do |t|
            t.string :job_name
            t.string :welfares
            t.integer :job_lookup
            t.integer :job_feedback_rate
            t.integer :job_feedback_spend
            t.text :job_decript
            t.text :job_req
            t.text :job_location
            t.belongs_to :company
            t.belongs_to :spiderdate
            t.timestamps
        end

        create_table :companies_spiderdates, id: false do |t|
            t.belongs_to :companies
            t.belongs_to :spiderdates
        end
    end
end
