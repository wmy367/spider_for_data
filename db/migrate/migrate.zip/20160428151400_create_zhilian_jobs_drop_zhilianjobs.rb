class CreateZhilianJobsDropZhilianjobs < ActiveRecord::Migration

    def change

        drop_table :zhilianjobs

        create_table :zhilian_jobs do |t|
            t.string :job_name
            t.string :welfares
            t.integer :job_lookup
            t.integer :job_feedback_rate
            t.integer :job_feedback_spend
            t.text :job_decript
            t.text :job_req
            t.text :job_location
            t.belongs_to :company
            t.belongs_to :spiderdate
            t.timestamps
        end
    end
end
