class ModifyZhilianJobs < ActiveRecord::Migration

    def change

        change_table :zhilian_jobs do |t|
            t.belongs_to :spider_date
        end
    end
end
